<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
    </head>
    <body bgcolor="#48D1CC">
       <center>
        <form name="ghf" method="post" action="">
             <table border="0">
             <tbody bgcolor="#48D1CC">    
            <tr>
                <td>
                    First name:</td>
                <td><input type="text" name="t1" required placeholder="first name"></td>
            </tr>
            <tr>
            <td>middle name:</td>
            <td><input type="text" name="t2" required placeholder="middle name">
            </td></tr>
                    <br>
                    <tr><td>
                            last name:</td>
                        <td><input type="text" name="t3" required placeholder="last name">
                       </td></tr>
                        <br>
                        <tr><td>
            g_mail:</td>
                            <td><input type="email" name="t4" required placeholder="email">
                            </td></tr>
                    <br>
                    <tr><td>
                            address:</td>
                        <td><input type="text" name="t5" required placeholder="address">
                        </td>  </tr>
                        <br>
                <tr><td>
                        password:</td>
                    <td><input type="password" name="t6" required placeholder="password">
                   </td></tr><br><br>
                <tr><td colspan="2"><center><input type="submit" name="save" value="signup"></center></td></tr></tbody>
        </table>
        </form></center>
</body>
</html>
<?php
mysql_connect("localhost","root","");

mysql_select_db("dba");
if(isset($_POST['save']))
{
        $a=$_POST['t1'];
        $b=$_POST['t2'];
        $c=$_POST['t3'];
        $d=$_POST['t4'];
        $e=$_POST['t5'];
        $f=$_POST['t6'];
        $res=mysql_query("insert into signup values('$a','$b','$c','$d','$e','$f')");
        
        if($res)
        {
            echo"successfully inserted";
        }
       
}
?>