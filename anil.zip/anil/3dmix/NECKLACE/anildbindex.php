<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
    </head>
    <body>
        <form name="ghf" method="post" action="">
            name:<input type="text" name="t1">
            class:<input type="text" name="t2">
            <input type="submit" name="save" value="save">
        </form>
   </body>
</html>
<?php
mysql_connect("localhost","root","");

mysql_select_db("anil");
if(isset($_POST['save']))
{
        $a=$_post['t1'];
        $b=$_post['t2'];
        $res=mysql_query("insert into reg values('$a','$b')");
        if($res)
        {
            echo"successfully inserted";
        }
       
}